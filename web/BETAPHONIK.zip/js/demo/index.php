<?php 

header("location: ../../404.html");

 ?>
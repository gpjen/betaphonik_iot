


Halaman planing, masa semai, masa peremajaan, kalkulasi perkiraan masa panen dari nilai nutrisi berjalan.